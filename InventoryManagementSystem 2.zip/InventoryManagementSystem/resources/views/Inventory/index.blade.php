@include('Include.app')

              <!-- content @s -->
              <div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">

                            @if($message = Session::get('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong>  {{ session()->get('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

                                <div class="nk-block-head">
                                    <div class="nk-block-head-between flex-wrap gap g-2">
                                        <div class="nk-block-head-content">
                                            <h2 class="nk-block-title">Inventory Management</h1>
                                        </div>
                                        <div class="nk-block-head-content">
                                            <ul class="d-flex">
                                                <li>
                                                    <a href="{{ route('Inventory.create') }}" class="btn btn-md d-md-none btn-primary">
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add Inventory</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="{{ route('Inventory.create') }}" class="btn btn-primary d-none d-md-inline-flex" >
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add Inventory</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div><!-- .nk-block-head-between -->
                                </div><!-- .nk-block-head -->
                                <div class="nk-block">
                                    <div class="card">
                                        <table class="datatable-init table" data-nk-container="table-responsive">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="tb-col">
                                                        <span class="overline-title">No</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Name</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">SKU</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Category</span>
                                                    </th>
                                                    <th class="tb-col tb-col-xl">
                                                        <span class="overline-title">Location</span>
                                                    </th>
                                                    <th class="tb-col tb-col-xl">
                                                        <span class="overline-title">Quantity</span>
                                                    </th>
                    
                                                    <th class="tb-col tb-col-end" data-sortable="false">
                                                        <span class="overline-title">Action</span>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            @foreach ($inventory as $key => $inv)
  <tr>
    <td>{{ ++$key }}</td>
    <td>{{ $inv->name }}</td>
    <td>{{ $inv->sku }}</td>
    <td>{{ $inv->CATEGORIES->category_name }}</td>
    <td>{{ $inv->LOCATIONS->warehouse }}</td>
    <td>{{ $inv->quantity }}</td>
   
    <td>
    <a class="btn btn-warning" href="{{ route('Inventory.edit',$inv->id) }}">Edit</a>
       <a class="btn btn-info" href="{{ route('Inventory.show',$inv->id) }}">View</a>
       {!! Form::open(['method' => 'DELETE','route' => ['Inventory.destroy', $inv->id],'style'=>'display:inline']) !!}
        {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
    {!! Form::close() !!}
    </td>
  </tr>
 @endforeach
                                            </tbody>
                                        </table>
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div> <!-- .nk-content -->
               @include('Include.footer')