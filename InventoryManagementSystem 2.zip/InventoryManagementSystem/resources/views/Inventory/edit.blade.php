@include('Include.app')



<div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">

                            <div class="nk-block">
                            @if($message = Session::get('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Whoops !</strong>  {{ session()->get('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

                                    <div class="nk-block-head">
                                        <div class="nk-block-head-content wide-md">
                                            <h3 class="nk-block-title">Edit Inventory </h3>
                                           
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                        {!! Form::model($inv, ['method' => 'PATCH','route' => ['Inventory.update', $inv->id]]) !!}
                
                                        <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="category" class="form-label">Category</label>
                                                        <div class="form-control-wrap">
                                                        <select id="category" name="category" class="form-select" required>
                                                                <option selected disabled>-- Select Category --</option>
                                                                @foreach($category as $cat)
                                                        <option value="{{ $cat->id }}" @if($cat->id == $inv->category) selected @endif>{{ $cat->category_name }}</option>
                                                                @endforeach
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="location" class="form-label">Location</label>
                                                        <div class="form-control-wrap">
                                                        <select id="location" name="location" class="form-select" required>
                                                                <option selected disabled>-- Select Location --</option>
                                                                @foreach($warehouse as $wh)
                                                        <option value="{{ $wh->id }}" @if($wh->id == $inv->location) selected @endif>{{ $wh->warehouse }}</option>
                                                                @endforeach
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                        </div>
                                                <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress" class="form-label">SKU</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" class="form-control" id="sku" name="sku" value="{{ $inv->sku }}" placeholder="SKU" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress2" class="form-label">Name</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" class="form-control" id="name" name="name" value="{{ $inv->name }}" placeholder="Product Name" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputCity" class="form-label">Quantity</label>
                                                        <div class="form-control-wrap">
                                                            <input type="number" class="form-control" id="quantity" name="quantity" value="{{ $inv->quantity }}" min="1" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputState" class="form-label">Supplier</label>
                                                        <div class="form-control-wrap">
                                                        <input type="text" class="form-control" id="supplier" name="supplier" value="{{ $inv->supplier }}" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>    <br>    <br>    <br>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </form>
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->

</div>
</div>
</div>
</div>
</div>
               @include('Include.footer')