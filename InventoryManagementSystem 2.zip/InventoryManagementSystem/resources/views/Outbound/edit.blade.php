@include('Include.app')

<script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>

<div class="nk-content" style="margin-top:5%;">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">

                            <div class="nk-block">
                            @if($message = Session::get('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Whoops !</strong>  {{ session()->get('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

                                    <div class="nk-block-head">
                                        <div class="nk-block-head-content wide-md">
                                            <h3 class="nk-block-title">Edit Outbound </h3>
                                           
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                           
                                        {!! Form::model($outbound, ['method' => 'PATCH','route' => ['Outbound.update', $outbound->id]]) !!}
                                        <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="category" class="form-label">Inventory</label>
                                                        <div class="form-control-wrap">
                                                        <select id="product_id" name="product_id" class="form-select" required>
                                                                <option selected disabled>-- Select Inventory --</option>
                                                                @foreach($inventory as $inv)
                                                        <option value="{{ $inv->id }}" data-qty="{{ $inv->quantity }}" @if($outbound->product_id == $inv->id) selected @endif>Product Name: {{ $inv->name }} || Category: {{ $inv->CATEGORIES->category_name }} || Location: {{ $inv->LOCATIONS->warehouse }} || SKU: {{ $inv->sku }}</option>
                                                                @endforeach
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                        </div>
                                                <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress" class="form-label">Reference</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" class="form-control" id="reference" name="reference" placeholder="Reference" value="{{ $outbound->reference }}" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress2" class="form-label">Date Shipped</label>
                                                        <div class="form-control-wrap">
                                                            <input type="date" class="form-control" id="date_shipped" name="date_shipped" value="{{ $outbound->date_shipped }}"  required>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                
                                                <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputCity" class="form-label">Quantity</label>
                                                        <div class="form-control-wrap">
                                                            <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="{{ $outbound->quantity }}" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputState" class="form-label">Destination</label>
                                                        <div class="form-control-wrap">
                                                        <input type="text" class="form-control" id="destination" name="destination" value="{{ $outbound->destination }}" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="inputState" class="form-label">Remarks</label>
                                                        <div class="form-control-wrap">
                                                            <textarea class="form-control" name="remarks" id="remarks" rows="7" maxlength="500" required>{{ $outbound->remarks }}</textarea>

                                                        </div>
                                                    </div>
                                                </div>
                                                   <br>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </form>
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->

</div>
</div>
</div>
</div>


<script>
$(document).ready(function(){

$('#product_id').on('change', function()
{
    var qty = $('option:selected', this).data('qty');

    $("#quantity").attr({
   "max" : qty,
   "min" : 1
});

});
});

</script>
               @include('Include.footer')