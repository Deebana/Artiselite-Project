<?php echo $__env->make('Include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- content @s  -->
                <div class="nk-content" style="background-color: white;">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
              <h1>Welcome To <b style="color:purple;">Inventory Management System</b></h1>
              <img src="inventoryhomeimg.gif">
                            </div>
                        </div>
                    </div>
                </div> <!-- .nk-content -->
               <?php echo $__env->make('Include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/InventoryManagementSystem/resources/views/home.blade.php ENDPATH**/ ?>