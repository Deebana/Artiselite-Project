<!DOCTYPE html>
<html lang="en">

<head>
    <base href="../../">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Multi-purpose admin dashboard template that especially build for programmers.">
    <title>Login - Inventory Management Controller</title>
    <link rel="shortcut icon" href="inventory.png">
    <link rel="stylesheet" href="./assets/css/style.css?v1.1.1">
</head>

<style>
    body{
        background-color:  #DEE5EE;
    }
</style>

<body class="nk-body" data-sidebar-collapse="lg" data-navbar-collapse="lg">
    <!-- Root  -->
    <div class="nk-app-root">
        <!-- main  -->
        <div class="nk-main">
            <div class="nk-wrap align-items-center justify-content-center">
                <div class="container p-2 p-sm-4">
                    <div class="wide-xs mx-auto">
                        <div class="text-center mb-5">
                            <div class="brand-logo mb-1">
                                <a href="/" class="logo-link">
                                    <div class="logo-wrap">
                                        <img style="width:250px; height:100px;" class="logo-img logo-light" src="inventorylogo.png" srcset="inventorylogo.png 2x"  alt="">
                                        <img style="width:250px; height:100px;" class="logo-img logo-dark" src="inventorylogo.png" srcset="inventorylogo.png 2x" alt="">
                                        <img style="width:250px; height:100px;" class="logo-img logo-icon" src="inventorylogo.png" srcset="inventorylogo.png 2x" alt="">
                                    </div>
                                </a>
                            </div>
                        
                        </div>
                        <div class="card card-gutter-lg rounded-4 card-auth">
                            <div class="card-body">
                                <div class="nk-block-head">
                                    <div class="nk-block-head-content">
                                        <h3 class="nk-block-title mb-1">Login to Account [Warehouse]</h3>
                                        <p class="small">Please sign-in to your account.</p>
                                    </div>
                                </div>

                                <?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Whoops !</strong>  <?php echo e(session()->get('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong>  <?php echo e(session()->get('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<form action="loginwarehouse" method="POST" autocomplete="off" aria-autocomplete="off">
                                            <?php echo csrf_field(); ?>
                                    <div class="row gy-3">
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="username" class="form-label">Email</label>
                                                <div class="form-control-wrap">
                                                    <input type="email" class="form-control" name="email" placeholder="Enter Email" required>
                                                </div>
                                            </div><!-- .form-group -->
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label for="password" class="form-label">Password</label>
                                                <div class="form-control-wrap">
                                                    <input type="password" class="form-control" name="password" placeholder="Enter Password" required>
                                                </div>
                                            </div><!-- .form-group -->
                                        </div>
                                        <div class="col-12">
                                            <div class="d-grid">
                                                <button class="btn btn-primary" type="submit">Login to account</button>
                                            </div>
                                        </div>
                                    </div><!-- .row -->
                                </form>
                            </div><!-- .card-body -->
                        </div><!-- .card -->
                     
                    </div><!-- .col -->
                </div><!-- .container -->
            </div>
        </div> <!-- .nk-main -->
    </div> <!-- .nk-app-root -->
</body>
<!-- JavaScript -->
<script src="./assets/js/bundle.js"></script>
<script src="./assets/js/scripts.js"></script>

</html><?php /**PATH /Applications/MAMP/htdocs/InventoryManagementSystem/resources/views/Auth/Login.blade.php ENDPATH**/ ?>