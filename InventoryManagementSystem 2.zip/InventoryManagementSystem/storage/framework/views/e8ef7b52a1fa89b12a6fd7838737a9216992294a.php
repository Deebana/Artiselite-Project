<?php echo $__env->make('Include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">

                            <div class="nk-block">
                            <?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Whoops !</strong>  <?php echo e(session()->get('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

                                    <div class="nk-block-head">
                                        <div class="nk-block-head-content wide-md">
                                            <h3 class="nk-block-title">Edit Inventory </h3>
                                           
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                        <?php echo Form::model($inv, ['method' => 'PATCH','route' => ['Inventory.update', $inv->id]]); ?>

                
                                        <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="category" class="form-label">Category</label>
                                                        <div class="form-control-wrap">
                                                        <select id="category" name="category" class="form-select" required>
                                                                <option selected disabled>-- Select Category --</option>
                                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $inv->category): ?> selected <?php endif; ?>><?php echo e($cat->category_name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="location" class="form-label">Location</label>
                                                        <div class="form-control-wrap">
                                                        <select id="location" name="location" class="form-select" required>
                                                                <option selected disabled>-- Select Location --</option>
                                                                <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($wh->id); ?>" <?php if($wh->id == $inv->location): ?> selected <?php endif; ?>><?php echo e($wh->warehouse); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                        </div>
                                                <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress" class="form-label">SKU</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" class="form-control" id="sku" name="sku" value="<?php echo e($inv->sku); ?>" placeholder="SKU" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress2" class="form-label">Name</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($inv->name); ?>" placeholder="Product Name" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputCity" class="form-label">Quantity</label>
                                                        <div class="form-control-wrap">
                                                            <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($inv->quantity); ?>" min="1" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputState" class="form-label">Supplier</label>
                                                        <div class="form-control-wrap">
                                                        <input type="text" class="form-control" id="supplier" name="supplier" value="<?php echo e($inv->supplier); ?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br>    <br>    <br>    <br>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </form>
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->

</div>
</div>
</div>
</div>
</div>
               <?php echo $__env->make('Include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/InventoryManagementSystem/resources/views/Inventory/edit.blade.php ENDPATH**/ ?>