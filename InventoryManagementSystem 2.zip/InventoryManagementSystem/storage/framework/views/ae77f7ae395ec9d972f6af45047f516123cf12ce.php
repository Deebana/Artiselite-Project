 <!-- include Footer -->
 <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright"> &copy; 2023 Inventory Management System.</a>
                            </div>
                      
                        </div>
                    </div>
                </div><!-- .nk-footer -->
            </div> <!-- .nk-wrap -->
        </div> <!-- .nk-main -->
    </div> <!-- .nk-app-root -->
</body>
<!-- JavaScript -->
<script src="./assets/js/bundle.js"></script>
<script src="./assets/js/scripts.js"></script>
<script src="./assets/js/data-tables/data-tables.js"></script>

</html><?php /**PATH /Applications/MAMP/htdocs/InventoryManagementSystem/resources/views/Include/footer.blade.php ENDPATH**/ ?>