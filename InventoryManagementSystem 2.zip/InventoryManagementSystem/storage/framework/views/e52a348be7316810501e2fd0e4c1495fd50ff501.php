<?php echo $__env->make('Include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>

<div class="nk-content" style="margin-top:5%;">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">

                            <div class="nk-block">
                            <?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Whoops !</strong>  <?php echo e(session()->get('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

                                    <div class="nk-block-head">
                                        <div class="nk-block-head-content wide-md">
                                            <h3 class="nk-block-title">Add Inbound </h3>
                                           
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-body">
                                           
                                        <?php echo Form::open(array('route' => 'Inbound.store','method'=>'POST')); ?>

                                        <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="category" class="form-label">Inventory</label>
                                                        <div class="form-control-wrap">
                                                        <select id="product_id" name="product_id" class="form-select" required>
                                                                <option selected disabled>-- Select Inventory --</option>
                                                                <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($inv->id); ?>" data-qty="<?php echo e($inv->quantity); ?>">Product Name: <?php echo e($inv->name); ?> || Category: <?php echo e($inv->CATEGORIES->category_name); ?> || Location: <?php echo e($inv->LOCATIONS->warehouse); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                        </div>
                                                <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress" class="form-label">Reference</label>
                                                        <div class="form-control-wrap">
                                                            <input type="text" class="form-control" id="reference" name="reference" placeholder="Reference" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label for="inputAddress2" class="form-label">Date Received</label>
                                                        <div class="form-control-wrap">
                                                            <input type="date" class="form-control" id="date_received" name="date_received" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                
                                                <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputCity" class="form-label">Quantity</label>
                                                        <div class="form-control-wrap">
                                                            <input type="number" class="form-control" id="quantity" name="quantity" min="1" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputState" class="form-label">Location</label>
                                                        <div class="form-control-wrap">
                                                        <select id="location" name="location" class="form-select" required>
                                                                <option selected disabled>-- Select Location --</option>
                                                                <?php $__currentLoopData = $location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($loc->id); ?>"><?php echo e($loc->warehouse); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="inputState" class="form-label">Remarks</label>
                                                        <div class="form-control-wrap">
                                                            <textarea class="form-control" name="remarks" id="remarks" rows="7" maxlength="500" required></textarea>

                                                        </div>
                                                    </div>
                                                </div>
                                                   <br>
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->

</div>
</div>
</div>
</div>
               <?php echo $__env->make('Include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/InventoryManagementSystem/resources/views/Inbound/create.blade.php ENDPATH**/ ?>