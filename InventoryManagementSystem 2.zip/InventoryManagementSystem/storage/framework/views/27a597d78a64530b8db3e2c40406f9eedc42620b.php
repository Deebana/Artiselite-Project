<?php echo $__env->make('Include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

              <!-- content @s  -->
              <div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">

                            <?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <strong>Success!</strong>  <?php echo e(session()->get('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

                                <div class="nk-block-head">
                                    <div class="nk-block-head-between flex-wrap gap g-2">
                                        <div class="nk-block-head-content">
                                            <h2 class="nk-block-title">Inbound Management</h1>
                                        </div>
                                        <div class="nk-block-head-content">
                                            <ul class="d-flex">
                                                <li>
                                                    <a href="<?php echo e(route('Inbound.create')); ?>" class="btn btn-md d-md-none btn-primary">
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add Inbound</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('Inbound.create')); ?>" class="btn btn-primary d-none d-md-inline-flex" >
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add Inbound</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div><!-- .nk-block-head-between -->
                                </div><!-- .nk-block-head -->
                                <div class="nk-block">
                                    <div class="card">
                                        <table class="datatable-init table" data-nk-container="table-responsive">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="tb-col">
                                                        <span class="overline-title">No</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Inventory</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Date Received</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Quantity</span>
                                                    </th>
                                                    <th class="tb-col tb-col-xl">
                                                        <span class="overline-title">Location</span>
                                                    </th>
                                                    <th class="tb-col tb-col-end" data-sortable="false">
                                                        <span class="overline-title">Action</span>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $inbound; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $in): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e(++$key); ?></td>
    <td><?php echo e($in->PRODUCT->name); ?></td>
    <td><?php echo e($in->date_received); ?></td>
    <td><?php echo e($in->quantity); ?></td>
    <td><?php echo e($in->LOCATIONS->warehouse); ?></td>
   
    <td>
    <a class="btn btn-warning" href="<?php echo e(route('Inbound.edit',$in->id)); ?>">Edit</a>
       <a class="btn btn-info" href="<?php echo e(route('Inbound.show',$in->id)); ?>">View</a>

       <?php echo Form::open(['method' => 'DELETE','route' => ['Inbound.destroy', $in->id],'style'=>'display:inline']); ?>

        <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

    <?php echo Form::close(); ?>

    </td>
  </tr>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div> <!-- .nk-content -->
               <?php echo $__env->make('Include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/InventoryManagementSystem/resources/views/Inbound/index.blade.php ENDPATH**/ ?>