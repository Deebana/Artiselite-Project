<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\inventory;
use App\category;
use App\warehouse_location;
use Carbon\Carbon;

class InventoryController extends Controller
{

    function __construct()
    {
        $this->middleware('permission:Inventory-Management');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $inventory = inventory::all();

       return view('Inventory.index',compact('inventory'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $category = category::all();
        $warehouse = warehouse_location::all();

        return view('Inventory.create',compact('category','warehouse'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $checksku = inventory::where('sku',$request->input('sku'))->count();

        if($checksku > 0){
            return redirect()->back()->with('error', 'SKU Already Exist, Please try again');
        }

        inventory::create([
        'category' => $request->input('category'),
        'sku'  => $request->input('sku'),
        'name'  => $request->input('name'),
        'location'  => $request->input('location'),
        'quantity'  => $request->input('quantity'),
        'supplier' => $request->input('supplier'),
        'created_at' => Carbon::now(),
        'created_by' => auth()->user()->id,
        'updated_at' => Carbon::now(),
        'updated_by' => auth()->user()->id
        ]);

        return redirect('/inventorylist')->with('success', 'Inventory has been inserted successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $inv = inventory::find($id);
        $category = category::all();
        $warehouse = warehouse_location::all();
    
        return view('Inventory.show',compact('inv','category','warehouse'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $inv = inventory::find($id);
        $category = category::all();
        $warehouse = warehouse_location::all();
    
        return view('Inventory.edit',compact('inv','category','warehouse'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $getinv = inventory::where('id',$id)->first();

        if($getinv->sku !=  $request->input('sku')){
        $checksku = inventory::where('sku',$request->input('sku'))->count();

        if($checksku > 0){
            return redirect()->back()->with('error', 'SKU Already Exist, Please try again');
        }
        }

        inventory::where('id',$id)->update([
        'category' => $request->input('category'),
        'sku'  => $request->input('sku'),
        'name'  => $request->input('name'),
        'location'  => $request->input('location'),
        'quantity'  => $request->input('quantity'),
        'supplier' => $request->input('supplier'),
        'updated_at' => Carbon::now(),
        'updated_by' => auth()->user()->id
        ]);

        return redirect('/inventorylist')->with('success', 'Inventory has been updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        inventory::find($id)->delete();
        return redirect()->route('Inventory.index')
                        ->with('success','Inventory deleted successfully');
    }
}
