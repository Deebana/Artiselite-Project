<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Outbound;
use App\inventory;
use Carbon\Carbon;

class OutboundController extends Controller
{

    function __construct()
    {
        $this->middleware('permission:Outbound-Management');
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $outbound = Outbound::all();

       return view('Outbound.index',compact('outbound'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $inventory = inventory::where('quantity','>','0')->get();

        return view('Outbound.create',compact('inventory'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $getinv = inventory::where('id',$request->input('product_id'))->first();

        $deductqty = $getinv->quantity - $request->input('quantity');

        inventory::where('id',$request->input('product_id'))->update([
            'quantity' => $deductqty
        ]);


        Outbound::create([
            'reference' => $request->input('reference'),
            'date_shipped'  => $request->input('date_shipped'),
            'product_id'  => $request->input('product_id'),
            'quantity'  => $request->input('quantity'),
            'destination'  => $request->input('destination'),
            'remarks' => $request->input('remarks'),
            'created_at' => Carbon::now(),
            'created_by' => auth()->user()->id
            ]);
    
            return redirect('/outboundlist')->with('success', 'Outbound has been inserted successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $outbound = Outbound::find($id);
        $inventory = inventory::all();
    
        return view('Outbound.show',compact('inventory','outbound'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $outbound = Outbound::find($id);
        $inventory = inventory::all();
    
        return view('Outbound.edit',compact('inventory','outbound'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $outbound = Outbound::find($id);

        $originalqty = $outbound->quantity;
        $newqty = $request->input('quantity');

        if($originalqty != $newqty){

        $qty = $originalqty - $newqty;



        $getinv = inventory::where('id',$request->input('product_id'))->first();

        $addqty = $getinv->quantity + $qty;

        inventory::where('id',$request->input('product_id'))->update([
            'quantity' => $addqty
        ]);

        }
        
        Outbound::where('id',$id)->update([
            'reference' => $request->input('reference'),
            'date_shipped'  => $request->input('date_shipped'),
            'product_id'  => $request->input('product_id'),
            'quantity'  => $request->input('quantity'),
            'destination'  => $request->input('destination'),
            'remarks' => $request->input('remarks'),
            'updated_at' => Carbon::now()
            ]);
    
            return redirect('/outboundlist')->with('success', 'Outbound has been updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Outbound::find($id)->delete();
        return redirect()->route('Outbound.index')
                        ->with('success','Outbound deleted successfully');
    }
}
