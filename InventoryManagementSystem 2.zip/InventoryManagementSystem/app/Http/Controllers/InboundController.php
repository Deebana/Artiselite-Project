<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Inbound;
use App\inventory;
use Carbon\Carbon;
use App\warehouse_location;

class InboundController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:Inbound-Management');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $inbound = Inbound::all();

       return view('Inbound.index',compact('inbound'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $inventory = inventory::where('quantity','>','0')->get();
        $location = warehouse_location::all();

        return view('Inbound.create',compact('inventory','location'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $getinv = inventory::where('id',$request->input('product_id'))->first();

        $addqty = $getinv->quantity + $request->input('quantity');

        inventory::where('id',$request->input('product_id'))->update([
            'quantity' => $addqty
        ]);


        Inbound::create([
            'reference' => $request->input('reference'),
            'date_received'  => $request->input('date_received'),
            'product_id'  => $request->input('product_id'),
            'quantity'  => $request->input('quantity'),
            'location'  => $request->input('location'),
            'remarks' => $request->input('remarks'),
            'created_at' => Carbon::now(),
            'created_by' => auth()->user()->id
            ]);
    
            return redirect('/inboundlist')->with('success', 'Inbound has been inserted successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $inbound = Inbound::find($id);
        $inventory = inventory::where('quantity','>','0')->get();

        $location = warehouse_location::all();

        return view('Inbound.show',compact('inbound','inventory','location'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $inbound = Inbound::find($id);
        $inventory = inventory::where('quantity','>','0')->get();
        $location = warehouse_location::all();

       return view('Inbound.edit',compact('inbound','inventory','location'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $inbound = Inbound::find($id);

        $originalqty = $inbound->quantity;
        $newqty = $request->input('quantity');

        if($originalqty != $newqty){

        $qty = $originalqty - $newqty;

        $getinv = inventory::where('id',$request->input('product_id'))->first();

        $addqty = $getinv->quantity - $qty;

        inventory::where('id',$request->input('product_id'))->update([
            'quantity' => $addqty
        ]);

        }

        Inbound::where('id',$id)->update([
            'reference' => $request->input('reference'),
            'date_received'  => $request->input('date_received'),
            'product_id'  => $request->input('product_id'),
            'quantity'  => $request->input('quantity'),
            'location'  => $request->input('location'),
            'remarks' => $request->input('remarks'),
            'updated_at' => Carbon::now(),
            ]);
    
            return redirect('/inboundlist')->with('success', 'Inbound has been updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Inbound::find($id)->delete();
        return redirect()->route('Inbound.index')
                        ->with('success','Inbound deleted successfully');
    }
}
