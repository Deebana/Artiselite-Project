<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Inbound extends Model
{
    protected $table = 'Inbound';
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'reference', 'date_received', 'product_id', 'quantity','original_quantity','location', 'remarks', 'created_at', 'created_by'
    ];

    public function PRODUCT()
    {
        return $this->belongsTo('App\inventory', 'product_id');
    }

    public function LOCATIONS()
    {
        return $this->belongsTo('App\warehouse_location', 'location');
    }
}
