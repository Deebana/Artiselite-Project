<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Outbound extends Model
{
    protected $table = 'Outbound';
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'reference', 'date_shipped', 'product_id', 'quantity', 'destination', 'remarks', 'created_at', 'created_by'
    ];

    public function PRODUCT()
    {
        return $this->belongsTo('App\inventory', 'product_id');
    }
}

