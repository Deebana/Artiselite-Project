<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class inventory extends Model
{
    protected $table = 'inventory';
    use SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'category', 'sku', 'name', 'location', 'quantity', 'supplier', 'created_at', 'created_by', 'updated_at', 'updated_by'
    ];

    public function CATEGORIES()
    {
        return $this->belongsTo('App\category', 'category');
    }

    public function LOCATIONS()
    {
        return $this->belongsTo('App\warehouse_location', 'location');
    }
}
