<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class warehouse_location extends Model
{
    protected $table = 'warehouse_location';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id', 'warehouse', 'status', 'created_at'
    ];
    
}
