<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::group(['middleware' => ['guest']], function () { 
// Authentication
Route::get('/','AuthenticationController@index')->name('/');
Route::post('loginwarehouse','AuthenticationController@login');
});


Route::group(['middleware' => ['auth']], function () { 

Route::get('/logoutwh','AuthenticationController@logoutwh');

//home
Route::get('/home','HomeController@index');

//User Management
Route::resource('Users', UsersController::class);
Route::get('/userlist','UsersController@index');
Route::get('/adduser','UsersController@create');

Route::resource('roles', RoleController::class);
Route::get('/rolelist','RoleController@index');


//Inventory
Route::resource('Inventory', InventoryController::class);
Route::get('/inventorylist','InventoryController@index');

//Inbound
Route::resource('Inbound', InboundController::class);
Route::get('/inboundlist','InboundController@index');

//Inventory
Route::resource('Outbound', OutboundController::class);
Route::get('/outboundlist','OutboundController@index');

});